package mydemo;
import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;

@Test
public class Deposit {
	public static void main(String[] args) {
		Deposit deposit = new Deposit();
		deposit.deposittest();
		}
	public void deposittest() {
		ExtentReports extent;
		ExtentTest test;
		
		extent = new ExtentReports("C:\\Users\\sarvin\\eclipse-workspace\\AutomationProject\\test_reports\\Deposit.html",true);
		test = extent.startTest("Deposit Test");
		
		System.setProperty("webdriver.gecko.driver","D:\\firefoxdriver\\geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette",true);
		WebDriver driver =new FirefoxDriver(capabilities);
		driver.navigate().to("http://localhost:8080/index");
		test.log(LogStatus.PASS, "Navigates into the Login page");
		driver.findElement(By.name("username")).sendKeys("test123");
		driver.findElement(By.name("password")).sendKeys("test123");
		driver.findElement(By.id("remember-me")).click();
		driver.findElement(By.id("submit")).click();
		test.log(LogStatus.PASS, "Successfully Signed");
		driver.findElement(By.xpath("//div[2]/div/a/div/div")).click();
		test.log(LogStatus.PASS, "Primary Account Transfer started");
		driver.findElement(By.id("accountType")).click();
		driver.findElement(By.xpath("//option[2]")).click();
		driver.findElement(By.id("amount")).sendKeys("500");
		test.log(LogStatus.PASS, "Check the Amount");
		driver.findElement(By.xpath("//form/button")).click();
		test.log(LogStatus.PASS, "Successfully Deposited");
		extent.endTest(test);
		extent.flush();
	}
}

