package mydemo;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByName;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.Test;
import com.relevantcodes.extentreports.ExtentReports;
import com.relevantcodes.extentreports.ExtentTest;
import com.relevantcodes.extentreports.LogStatus;
@Test
public class Registration {
	public static void main(String[] args) {
		
		Registration register = new Registration();
		register.registerTest();
		}


	public void registerTest() {
		ExtentReports extent;
		ExtentTest test;
		
		extent = new ExtentReports("C:\\Users\\sarvin\\eclipse-workspace\\AutomationProject\\test_reports\\registerTest.html",true);
		test = extent.startTest("register Test");
	
		System.setProperty("webdriver.gecko.driver","D:\\firefoxdriver\\geckodriver.exe");
		DesiredCapabilities capabilities = DesiredCapabilities.firefox();
		capabilities.setCapability("marionette",true);
		WebDriver driver =new FirefoxDriver(capabilities);
		driver.navigate().to("http://localhost:8080/index");
		test.log(LogStatus.PASS, "Navigates into the Login page");
		driver.findElement(By.linkText("Sign up!")).click();
		test.log(LogStatus.PASS, "Navigates into the Login page");
		driver.findElement(By.id("firstName")).sendKeys("Sarvin");
		driver.findElement(By.id("lastName")).sendKeys("Selva");
		driver.findElement(By.id("phone")).sendKeys("1234567890");
		driver.findElement(By.id("email")).sendKeys("13@gmail.com");
		driver.findElement(By.id("firstName")).sendKeys("Sarvin");
		driver.findElement(By.id("username")).sendKeys("tst123");
		driver.findElement(By.id("password")).sendKeys("test123");
		driver.findElement(By.id("showPassword")).click();
		driver.findElement(By.xpath("//button")).click();
		test.log(LogStatus.PASS, "Successfully Registered");
		extent.endTest(test);
		extent.flush();
	}
}